prompt --application/deployment/install/install_opt_echema
begin
--   Manifest
--     INSTALL: INSTALL-opt_echema
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>54888110149374270558
,p_default_application_id=>265559
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARNERP'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(54953448754380323062)
,p_install_id=>wwv_flow_imp.id(54953409784963318703)
,p_name=>'opt_echema'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  CREATE TABLE "USERS" ',
'   (	"USERID" NUMBER, ',
'	"USERNAME" VARCHAR2(300), ',
'	"PASSWORD" VARCHAR2(300), ',
'	"STATUS" VARCHAR2(10), ',
'	"MOBILE" NUMBER, ',
'	"EMAIL" VARCHAR2(30), ',
'	 PRIMARY KEY ("USERID")',
'  USING INDEX  ENABLE, ',
'	 UNIQUE ("USERNAME")',
'  USING INDEX  ENABLE',
'   ) ;',
'create or replace FUNCTION user_auth1 (p_username IN VARCHAR2, p_password VARCHAR2)',
' RETURN BOOLEAN',
'IS',
' temp number;',
'BEGIN',
'',
'   --Author Gul Rahman gulrahman40@gmail.com     @Pakistan',
'',
'',
' -- Validate whether the user exits or not',
'SELECT distinct 1 into temp',
'FROM USERS',
'WHERE upper(username) = UPPER (p_username) AND password= p_password and status=''UNLOCK'';',
'',
'RETURN TRUE;',
'EXCEPTION',
' WHEN NO_DATA_FOUND',
' THEN',
' RETURN FALSE;',
'END;',
'/',
'create or replace FUNCTION user_validation    (',
' p_usernam IN VARCHAR2, --User_Name',
' p_userpass IN VARCHAR2 -- Password',
')',
' RETURN NUMBER',
'AS',
' lc_pwd_exit number (1);',
'BEGIN',
'',
'   --Author Gul Rahman gulrahman40@gmail.com     @Pakistan',
'',
'   ',
' -- Validate whether the user exits or not',
' SELECT 1',
' INTO lc_pwd_exit',
' FROM users',
' WHERE upper(username) = UPPER (p_usernam) AND PASSWORD = P_userpass and status=''UNLOCK'' ;',
'RETURN 1;',
'EXCEPTION',
' WHEN NO_DATA_FOUND',
' THEN',
' RETURN 0;',
'END;',
'/',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(54953448857625323063)
,p_script_id=>wwv_flow_imp.id(54953448754380323062)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'USER_AUTH1'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_updated_on=>to_date('20230823202947','YYYYMMDDHH24MISS')
,p_created_by=>'ELWMO2005@GMAIL.COM'
,p_created_on=>to_date('20230823202947','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(54953449049940323063)
,p_script_id=>wwv_flow_imp.id(54953448754380323062)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'USER_VALIDATION'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_updated_on=>to_date('20230823202947','YYYYMMDDHH24MISS')
,p_created_by=>'ELWMO2005@GMAIL.COM'
,p_created_on=>to_date('20230823202947','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(54953449258246323063)
,p_script_id=>wwv_flow_imp.id(54953448754380323062)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'USERS'
,p_last_updated_by=>'ELWMO2005@GMAIL.COM'
,p_last_updated_on=>to_date('20230823202947','YYYYMMDDHH24MISS')
,p_created_by=>'ELWMO2005@GMAIL.COM'
,p_created_on=>to_date('20230823202947','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
