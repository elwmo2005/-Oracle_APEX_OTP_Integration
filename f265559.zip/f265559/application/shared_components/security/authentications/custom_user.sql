prompt --application/shared_components/security/authentications/custom_user
begin
--   Manifest
--     AUTHENTICATION: custom_user
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.3'
,p_default_workspace_id=>54888110149374270558
,p_default_application_id=>265559
,p_default_id_offset=>0
,p_default_owner=>'WKSP_ARNERP'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(54897593264111580499)
,p_name=>'custom_user'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'user_auth1'
,p_attribute_05=>'N'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
